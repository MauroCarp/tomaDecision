
<div class="sm:fixed sm:top-0 sm:right-0 p-6 text-right">
    @dump($record)
</div>

