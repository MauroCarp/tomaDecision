<?php dump($gim); ?>
<div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/caseClassify/resources/views/grade-image.blade.php ENDPATH**/ ?>