
    <?php if($urls): ?>

        <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div style="display: grid;place-items: center;">

                <img src="/storage/<?php echo e($image); ?>" alt="Image" width="650px">

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php else: ?>

        <p>No image available</p>

    <?php endif; ?>

<?php /**PATH /Applications/MAMP/htdocs/caseClassify/resources/views/components/image-view.blade.php ENDPATH**/ ?>