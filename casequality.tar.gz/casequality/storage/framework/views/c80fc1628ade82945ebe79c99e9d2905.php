<div class="fi-in-placeholder text-sm text-gray-400 dark:text-gray-500">
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Applications/MAMP/htdocs/caseClassify/vendor/filament/infolists/resources/views/components/entries/placeholder.blade.php ENDPATH**/ ?>