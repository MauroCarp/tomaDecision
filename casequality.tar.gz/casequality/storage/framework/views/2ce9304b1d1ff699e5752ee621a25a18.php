
    <!--[if BLOCK]><![endif]--><?php if($urls): ?>

        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div style="display: grid;place-items: center;">

                <img src="/storage/<?php echo e($image); ?>" alt="Image" width="650px">

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

    <?php else: ?>

        <p>No image available</p>

    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

<?php /**PATH /home/c1662044/public_html/casequality/resources/views/components/image-view.blade.php ENDPATH**/ ?>