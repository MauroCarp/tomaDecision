<h2
    <?php echo e($attributes->class(['fi-modal-heading text-base font-semibold leading-6 text-gray-950 dark:text-white'])); ?>

>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH /home/c1662044/public_html/casequality/vendor/filament/support/src/../resources/views/components/modal/heading.blade.php ENDPATH**/ ?>